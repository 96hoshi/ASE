from calc.views.home import home
from calc.views.calc import calc

blueprints = [home, calc]
